For other languages of this README, please refer to

[中文说明]( "中文说明")

# DSP Colorful Building Grid

## Screenshots

[images here]

## Introduction

This mod allows to change color of the building grid. When you enter building mode, a small panel with text 'Colorful grid' will appear at bottom-right corner of screen, check it to use custom color, click the cof icon to set the color, uncheck to restore to default color.

[image here]

Settings will be saved when you exit the game.

## Compatibility

### 0.0.1

Build target: game version 0.9.25.12201, BepInEx version: 5.4.19 (should work under 5.4.17)

## Change log

### 0.0.1

- Initial version
